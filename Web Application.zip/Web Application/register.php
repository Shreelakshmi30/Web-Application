<html>
<head>
<title> Registration page</title>
<link rel="stylesheet" type="text/css" href="style1.css">
</head>
<body>
<div class="rebox">
    <!-- <img src="2.jpg" class="register"> -->
<div class="register">
    <h1>REGISTER HERE</h1>

</div>
<?php
        
        $Name = $Age = $Contact = $Password = "" ;
        if($_SERVER["REQUEST_METHOD"]=="POST"){
            $User_Name = $_POST['name'];
            $User_ID = $_POST['UID'];
            $Phone_Number = $_POST['phone_number'];
            $Email_ID = $_POST['email'];
            $Password = $_POST['password'];
           
            
            $con = mysqli_connect("localhost","root","tweety","shopping");
                       
        
            $query = "INSERT INTO `User` (User_Name, User_ID, Phone_Number, Email_ID, Password) VALUES ('$User_Name', '$User_ID', 
            '$Phone_Number', '$Email_ID', '$Password')";
                        $result = mysqli_query($con,$query);
                        if($result)
     // extra line
             {
         echo ("<SCRIPT LANGUAGE='JavaScript'>
                 window.alert('You are registred successfully, Now login for further process');
                     window.location.href='login.php';             
                 </SCRIPT>");
           
                  }else{
                      echo("Invalid credentials");
                  }
          }
          else{
           
           // extra line    
        ?>

        
        <form class="p" action="" method="POST">
            User Name:
            <input type="text" id="Name" placeholder="Enter Name" name="name" required><br>
            User ID:
            <input type="text" id="UID" placeholder="Enter UID" name="UID" required><br>
            Phone Number:
            <input type="text" id="department" placeholder="Enter Phone number" name="phone_number" required><br>
            Email ID:
            <input type="text" id="email" placeholder="Enter Email" name="email" required> <br>
            <div> Password:
                <input type="text" id="password" placeholder="Enter password" name="password" required> </div> 
                 <a href="login.php">Already have an account?</a><br>
                 <a href="front_end.php">Home</a><br><br>
            <button type="submit"  name="submit" value="Register" >Register</button>

        </form>
    
</div>

<!-- extra line -->

    <?php } ?> 
</body>

</html>