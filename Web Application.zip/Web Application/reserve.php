<!DOCTYPE html>
<html>
<head>
<title>Reserve</title>
<link rel="stylesheet" type="text/css" href="style4.css">
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.2/animate.min.css">
 <link href="https://fonts.googleapis.com/css?family=Dancing+Script&display=swap" rel="stylesheet">
</head>

<body>

<div class="main animated slideInDown">
<div class="d1box">

<h1>Online Smartphone Shopping </h1>
	<!-- <img src="login.png" class="login"> -->
<h2>Reserve here</h2>
</div>

</div>

<br><br>
<div class="para">
<p1>INSTRUCTION: If you are new to this online shopping please follow this instruction. Below there is a reserve option enter the mobile name [make sure you have entered the full name of the mobile] you are willing to purchase then click on reserve button and your mobile will be reserved</p1>

</div>


<div class="dbox">


 <?php
  error_reporting(E_ERROR);
 ?>

    

<article>


<br><br><br><br>    
<form action="" method="post">
<br><input type="text"	placeholder="Enter mobile name" name="rmname" required=""> <br>
<button type="submit"> Reserve</button> <br><br><br>
</form>

<?php

// Create connection
$conn = mysqli_connect("localhost","root", "tweety","shopping");

// Check connection
 if (!$conn) {
die("Connection failed!!!!!! " . mysqli_connect_error());
 }

echo "Connected successfully";
if(isset($_POST['rmname'])){


$Mobilename = $_POST['rmname'];
$sql = "Update `mobile` SET Reservation ='YES' where Mobile_Name='$Mobilename'";

$result = mysqli_query($conn, $sql);
echo ("<SCRIPT LANGUAGE='JavaScript'>
  		  		 window.alert('Your smartphone has been reserved successfully!');
                                 
				 window.location.href='reserve.php';
  				 </SCRIPT>");

}
?>

</article>

</div>
</body>
</html>