<!DOCTYPE html>
<html>
<head>
<title>Search and Reserve</title>
<link rel="stylesheet" type="text/css" href="style3.css">
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.2/animate.min.css">
</head>

<body>

<div class="main animated slideInDown">
<div class="d1box">

<h1>Online Smartphone Shopping </h1>
	<!-- <img src="login.png" class="login"> -->
<h2>Search and Reserve here</h2>
</div>

</div>

<br><br>
<div class="para">
<p1>NOTE: Search the book you want and reserve in case while searching if the book you wanted is already sreserve it wont be displayed</p1>

</div>


<div class="dbox">


 <?php
  error_reporting(E_ERROR);
 ?>

    

<article>

<br><br><br><br>
<form action="" method="post">
<br><input type="text"	placeholder="Enter Book Title" name="bname" required=""><br>
<button type="submit"> SEARCH </button><br><br><br>
</form>

<?php

// Create connection
$conn = mysqli_connect("localhost","root", "tweety","library_management_system");

// Check connection
 if (!$conn) {
die("Connection failed!!!!!! " . mysqli_connect_error());
 }

echo "Connected successfully";
if(isset($_POST['bname'])){

$Booktitle = $_POST['bname'];
$sql = "select * from book_info where Book_Name LIKE '%$Booktitle%' and Reservation='NO'";

$result = mysqli_query($conn, $sql);
?>
<table border="1">
<tr>

<th>Book Name</th>
<th>Book ID</th>
<th>Book Author</th>
<th>Book Edition</th>
<th>Number of Books</th>
<th>Reservation</th>

</tr>

<?php while($row = mysqli_fetch_assoc($result)){ ?>
<tr>

<td><?php echo $row['Book_Name']; ?></td>

<td><?php echo $row['Book_ID']; ?></td>

<td><?php echo $row['Book_Author']; ?></td>

<td><?php echo $row['Book_Edition']; ?></td>

<td><?php echo $row['Number_of_books']; ?></td>

<td><?php echo $row['Reservation']; ?></td>

</tr>

<?php

}?>

</table><?php } ?>


</article>

<div class="button1">
<a href="reserve.php" class="btn1">reserve</a> 
</div>


</body>

</html>