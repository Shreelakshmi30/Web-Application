<!DOCTYPE html>
<html>
<head>
<title>Online Smartphone</title>
<link rel="stylesheet" type="text/css" href="style.css">
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.2/animate.min.css">
 <link href="https://fonts.googleapis.com/css?family=Dancing+Script&display=swap" rel="stylesheet">
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.2/animate.min.css">
 <!-- <link href="https://fonts.googleapis.com/css?family=Zhi+Mang+Xing&display=swap" rel="stylesheet"> -->
</head>

<body>

<div class="main animated slideInDown">
<div class="d1box">

<h1>Online Smartphone Shopping </h1>
	<!-- <img src="login.png" class="login"> -->
<h2>Welcome</h2>
</div> 
</div>

<div id="container">
	<div id="sliderbox">
		<img src="image/1.jpg">
		<img src="image/2.jpg">
		<img src="image/3.jpg">
		<img src="image/4.jpg">
		<img src="image/5.jpg">
		<img src="image/6.jpg">
		<img src="image/7.jpg">
		<img src="image/8.jpg">
		<img src="image/9.jpg">
		<img src="image/10.jpg">
	</div>
</div>

<div class="para">
 <p1> HELLO CUSTOMER!</p1>
 <p> Great Indian festival from 21st to 25th October, Diwali special offers click a button to register now to get get updates on promotions and coupons and explore new cellphone discounts or if you already have an account login and go head. Mobile phone usage is on rise and smartphone lovers are on a constant.</p>

	</div>
<div class="head3" >
	 <!-- color change animated -->
	 <h3> <span class="colorchange">HAPPY SHOPPING! HAPPY DIWALI!</span></h3>
</div>


<div class="button">
<a href="register.php" class="btn1">register</a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="login.php" class="btn2">login</a>

</div>


</body>

</html>