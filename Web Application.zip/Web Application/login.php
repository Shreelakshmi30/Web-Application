<html>
<head>
<title> Login page</title>
<link rel="stylesheet" type="text/css" href="style2.css">
</head>
<body>
  <!-- <img src="1.jpg" class="background"> -->
<div class="loginbox">

	<img src="login.png" class="login">
	<h1>Login Here</h1>

	<?php
        session_start();
        // put your code here
    if (isset($_POST['name'])) {
        $User_Name = $_POST['name'];	
        $Password = $_POST['password'];
        
        
        $con = mysqli_connect("localhost","root","tweety","shopping");
        
        if (mysqli_connect_errno())
                    {
                    echo "Failed to connect to MySQL: " . mysqli_connect_error();
                    }
		
		
			$query = "SELECT * FROM user WHERE User_Name='$User_Name' and Password='$Password'";
                        $result = mysqli_query($con,$query);
                        $count = mysqli_num_rows($result);
                        if($count==1){
                            $_SESSION["username"]=$User_Name;
			 echo ("<SCRIPT LANGUAGE='JavaScript'>
  		  		 window.alert('You are logged in successfully');
                                 
				 window.location.href='search.php';
  				 </SCRIPT>");
           
                  }else{
                      echo("Invalid credentials");
                  }
	      }
           
              else{
        ?>
        
        
     
        
        <form class="p"  action="" method="post">
            <br>
            User Name:
            <br><input type="text" id="name" placeholder="Enter your name" name="name" required> <br>
            Password:
            <br><input type="password" id="password" placeholder="Enter password" name="password" required> <br>
            <button type="submit"  name="submit" value="Register" >Login</button><br><br>
            <div class="fs">
            <a href="#">Lost your password?</a><br>
            <a href="register.php">Don't have an account? <br>
            Create an account</a><br>
            <a href="front_end.php">Home</a><br>
          </div>
          <!--   <a href="register.php">Go to register page</a><br> -->
        </form>

      

</div>
	<?php } ?>
</body>

</html>